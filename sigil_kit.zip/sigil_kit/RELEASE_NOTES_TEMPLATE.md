## vYYYY.WW – Codename
### Highlights
- [feat] ...
### Fixes
- [fix] ...
### Notes
- Compatibility / known issues
### Ritual
Open: “Generating please wait…” · Close: “Echo out 🧱🔥♾️💧” · Sign: ⏳♾️🛸
